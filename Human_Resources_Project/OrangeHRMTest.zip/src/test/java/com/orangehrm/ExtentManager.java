package com.orangehrm;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {
    private static final ExtentReports extent = new ExtentReports();
    static {
        ExtentSparkReporter spark = new ExtentSparkReporter("reports/ExtentReport.html");
        extent.attachReporter(spark);
    }
    public static ExtentReports getReporter() {
        return extent;
    }
}
