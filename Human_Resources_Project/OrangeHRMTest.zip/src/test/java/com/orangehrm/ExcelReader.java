package com.orangehrm;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ExcelReader {
    public static List<String[]> getData(String filePath) {
        List<String[]> data = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rows = sheet.iterator();
            rows.next(); // Skip header
            while (rows.hasNext()) {
                Row row = rows.next();
                String username = row.getCell(0) != null ? row.getCell(0).toString() : "";
                String password = row.getCell(1) != null ? row.getCell(1).toString() : "";
                data.add(new String[]{username, password});
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
}
