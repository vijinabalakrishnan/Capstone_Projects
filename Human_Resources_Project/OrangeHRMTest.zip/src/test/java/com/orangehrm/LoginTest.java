package com.orangehrm;

import com.aventstack.extentreports.*;
import org.openqa.selenium.*;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.*;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class LoginTest extends BaseTest {

    ExtentReports extent = ExtentManager.getReporter();

    @DataProvider
    public Object[][] loginData() {
        List<String[]> data = ExcelReader.getData("data/TestData.xlsx");
        Object[][] result = new Object[data.size()][2];
        for (int i = 0; i < data.size(); i++) {
            result[i] = data.get(i);
        }
        return result;
    }

    @Test(dataProvider = "loginData")
    public void testLogin(String username, String password) {
        ExtentTest test = extent.createTest("Login Test - " + username);
        setup();
        try {
            driver.get("https://opensource-demo.orangehrmlive.com/");
            test.info("Navigated to OrangeHRM");

            driver.findElement(By.name("username")).sendKeys(username);
            driver.findElement(By.name("password")).sendKeys(password);
            driver.findElement(By.cssSelector("button[type='submit']")).click();

            Thread.sleep(3000); // For UI response

            takeScreenshot(username + "_" + getTimestamp());
            if (username.equals("Admin") && password.equals("admin123")) {
                boolean dashboardExists = driver.findElements(By.xpath("//h6[text()='Dashboard']")).size() > 0;
                assert dashboardExists : "Login failed for valid user";
                test.pass("Valid credentials passed");
                driver.findElement(By.xpath("//p[@class='oxd-userdropdown-name']")).click();
                driver.findElement(By.linkText("Logout")).click();
                test.info("Logged out successfully");
            } else {
                boolean errorVisible = driver.findElements(By.className("oxd-alert-content-text")).size() > 0;
                assert errorVisible : "Login should fail for invalid credentials";
                test.pass("Invalid credentials rejected as expected");
            }
        } catch (Exception e) {
            test.fail("Test failed due to exception: " + e.getMessage());
        } finally {
            tearDown();
        }
    }

    @AfterSuite
    public void generateReport() {
        extent.flush();
    }

    public void takeScreenshot(String name) {
        try {
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String path = "screenshots/" + name + ".png";
            FileHandler.copy(src, new File(path));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getTimestamp() {
        return new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
    }
}
